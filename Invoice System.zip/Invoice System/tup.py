#!/usr/bin/python
# -*- coding: utf-8 -*-
from flask import Flask
from threading import Thread
from time import sleep
import webbrowser, platform

from views.init import url as init
from views.company import url as company
from views.invoice import url as invoice
from views.inventory import url as inventory
from views.party import url as party

app = Flask(__name__)

app.register_blueprint(init)
app.register_blueprint(company)
app.register_blueprint(invoice)
app.register_blueprint(inventory)
app.register_blueprint(party)

def openbrowser(host, port):
	sleep(5)
	url = "http://" + host + ":" + str(port)
	webbrowser.open(url, new=2)


if __name__ == '__main__':
	host = '0.0.0.0'
	port = 5000
	app.secret_key = 'super_secret_key'
	app.debug = True
	if platform.system() == 'Windows':
		host = 'localhost'
		port = 8000
		app.debug = False
	thread = Thread(target = openbrowser, args = (host, port))
	thread.start()
	app.run(host=host, port=port)
