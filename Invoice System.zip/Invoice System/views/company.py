#!/usr/bin/python
# -*- coding: utf-8 -*-
from flask import Blueprint, redirect, render_template, request
from flask import session as login_session

from sqlalchemy import create_engine, asc
from sqlalchemy.orm import sessionmaker
from database import Base, Company, dbpath

engine = create_engine(dbpath)
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
session = DBSession()

url = Blueprint('company', __name__)

@url.route('/company/create', methods=['POST'])
def create():
	data = request.json
	partyName = data['partyName']
	street = data['street']
	city = data['city']
	state = data['state']
	pincode = data['pincode']
	if 'gstRegistered' in data.keys():
		gstRegistered = data['gstRegistered']
	else:
		gstRegistered = ""
	if 'gstin' in data.keys():
		gstin = data['gstin']
	else:
		gstin = ""
	if 'compositionScheme' in data.keys():
		compositionScheme = data['compositionScheme']
	else:
		compositionScheme = ""
	if 'schemePercentage' in data.keys():
		schemePercentage = data['schemePercentage']
	else:
		schemePercentage = ""
	newCompany = Company(partyName = partyName,
							street = street,
    						city = city,
    						state = state,
    						pincode = pincode,
    						gstRegistered = gstRegistered,
    						gstin = gstin,
    						compositionScheme = compositionScheme,
    						schemePercentage = schemePercentage)
	session.add(newCompany)
	session.flush()
	session.refresh(newCompany)
	session.commit()
	login_session['company_id'] = newCompany.id
	if newCompany.id > 0:
		return str(newCompany.id)
	else:
		return "fail"
