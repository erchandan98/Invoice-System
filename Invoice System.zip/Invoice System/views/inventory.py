#!/usr/bin/python
# -*- coding: utf-8 -*-
from flask import Blueprint, jsonify, redirect, render_template, request
from flask import session as login_session

from sqlalchemy import create_engine, asc
from sqlalchemy.orm import sessionmaker
from database import Base, Item, dbpath

engine = create_engine(dbpath)
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
session = DBSession()

url = Blueprint('inventory', __name__)


@url.route('/inventory')
def inventory():
	return render_template('inventory.html')


@url.route('/inventory/getTopItems')
def getTopItems():
    items = session.query(Item).filter_by(company_id=login_session['company_id']).order_by(Item.time_updated.desc()).order_by(Item.time_created.desc()).order_by(Item.id.desc()).limit(8).all()
    return jsonify(items=[i.serialize for i in items])


@url.route('/inventory/getAllItems')
def getAllItems():
    items = session.query(Item).filter_by(company_id=login_session['company_id']).order_by(Item.id).all()
    return jsonify(items=[i.serialize for i in items])


@url.route('/inventory/getSearchItems')
def getSeachItems():
    searchText = request.args.get('searchText');
    items = session.query(Item).filter_by(company_id=login_session['company_id']).filter(Item.description.like("%"+searchText+"%")).order_by(Item.id.desc()).limit(8).all()
    return jsonify(items=[i.serialize for i in items])


@url.route('/inventory/createItem', methods=['POST'])
def createItem():
    data = request.json
    
    description = data['description']
    itemType = data['itemType']
    if 'hsnCode' in data.keys():
        hsnCode = data['hsnCode']
    else:
        hsnCode = ""
    if 'rate' in data.keys():
        rate = int(data['rate'])
    else:
        rate = ""
    if 'tax' in data.keys():
        tax = float(data['tax'])
    else:
        tax = 0
    if 'unitOfMeasurement' in data.keys():
        unitOfMeasurement = data['unitOfMeasurement']
    else:
        unitOfMeasurement = ""
    if 'notes' in data.keys():
        notes = data['notes']
    else:
        notes = ""
    newItem = Item(description=description,
                    itemType=itemType,
                    hsnCode=hsnCode,
                    rate=rate,
                    tax=tax,
                    unitOfMeasurement=unitOfMeasurement,
                    notes=notes,
                    company_id=login_session['company_id'])
    session.add(newItem)
    session.flush()
    session.refresh(newItem)
    session.commit()
    if newItem.id > 0:
    	return str(newItem.id)
    else:
    	return "fail"


@url.route('/inventory/item/<int:itemID>/delete', methods=['POST'])
def deleteItem(itemID):
    item = session.query(Item).filter_by(id=itemID).one()
    if item and item.company_id == login_session['company_id']:
        session.delete(item)
        session.commit()
        return 'true'
    else:
        return 'false'


@url.route('/inventory/item/<int:itemID>/edit', methods=['POST'])
def editItem(itemID):
    item = session.query(Item).filter_by(id=itemID).one()
    if item and item.company_id == login_session['company_id']:
        data = request.json
        item.description = data['description']
        item.itemType = data['itemType']
        item.rate = data['rate']
        item.tax = data['tax']
        item.hsnCode = data['hsnCode']
        item.unitOfMeasurement = data['unitOfMeasurement']
        item.notes = data['notes']
        session.flush()
        session.refresh(item)
        session.commit()
        return 'true'
    else:
        return 'false'
