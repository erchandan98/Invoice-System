#!/usr/bin/python
# -*- coding: utf-8 -*-
from flask import Blueprint, jsonify, redirect, render_template, request
from flask import session as login_session

from sqlalchemy import create_engine, asc
from sqlalchemy.orm import sessionmaker
from database import Base, Party, dbpath

engine = create_engine(dbpath)
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
session = DBSession()

url = Blueprint('party', __name__)


@url.route('/party')
def party():
	return render_template('party.html')


@url.route('/party/getAllParty')
def getAllParty():
    party = session.query(Party).filter_by(company_id=login_session['company_id']).order_by(Party.id).all()
    return jsonify(party=[i.serialize for i in party])


@url.route('/party/getTopParty')
def getTopParty():
    party = session.query(Party).filter_by(company_id=login_session['company_id']).order_by(Party.time_updated.desc()).order_by(Party.time_created.desc()).order_by(Party.id.desc()).limit(13).all()
    return jsonify(party=[i.serialize for i in party])


@url.route('/party/getSearchParty')
def getSearchParty():
    searchText = request.args.get('searchText');
    party = session.query(Party).filter_by(company_id=login_session['company_id']).filter(Party.name.like("%"+searchText+"%")).order_by(Party.id.desc()).limit(8).all()
    return jsonify(party=[i.serialize for i in party])


@url.route('/party/createParty', methods=['POST'])
def createParty():
    data = request.json
    
    partyType = data['partyType']
    name = data['name']
    state = data['state']
    if 'contactPerson' in data.keys():
        contactPerson = data['contactPerson']
    else:
        contactPerson = ""
    if 'gstin' in data.keys():
        gstin = data['gstin']
    else:
        gstin = ""
    if 'contactNumber' in data.keys():
        contactNumber = data['contactNumber']
    else:
        contactNumber = ''
    if 'street' in data.keys():
        street = data['street']
    else:
        street = ""
    if 'city' in data.keys():
        city = data['city']
    else:
        city = ""
    if 'pincode' in data.keys():
        pincode = data['pincode']
    else:
        pincode = ""
    if 'emailID' in data.keys():
        emailID = data['emailID']
    else:
        emailID = ""
    if 'landlineNo' in data.keys():
        landlineNo = data['landlineNo']
    else:
        landlineNo = ''
    newParty = Party(partyType=partyType,
                    name=name,
                    state=state,
                    contactPerson=contactPerson,
                    gstin=gstin,
                    contactNumber=contactNumber,
                    street=street,
                    city=city,
                    pincode=pincode,
                    emailID=emailID,
                    landlineNo=landlineNo,
                    company_id=login_session['company_id'])
    session.add(newParty)
    session.flush()
    session.refresh(newParty)
    session.commit()
    if newParty.id > 0:
    	return str(newParty.id)
    else:
    	return "fail"


@url.route('/party/<int:partyID>/delete', methods=['POST'])
def deleteParty(partyID):
    party = session.query(Party).filter_by(id=partyID).one()
    if party and party.company_id == login_session['company_id']:
        session.delete(party)
        session.commit()
        return 'true'
    else:
        return 'false'


@url.route('/party/<int:partyID>/edit', methods=['POST'])
def editParty(partyID):
    party = session.query(Party).filter_by(id=partyID).one()
    if party and party.company_id == login_session['company_id']:
        data = request.json
        party.partyType = data['partyType']
        party.name = data['name']
        party.contactPerson = data['contactPerson']
        party.gstin = data['gstin']
        party.contactNumber = data['contactNumber']
        party.street = data['street']
        party.city = data['city']
        party.state = data['state']
        party.pincode = data['pincode']
        party.emailID = data['emailID']
        party.landlineNo = data['landlineNo']
        session.flush()
        session.refresh(party)
        session.commit()
        return 'true'
    else:
        return 'false'
