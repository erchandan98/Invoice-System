#!/usr/bin/python
# -*- coding: utf-8 -*-
import datetime

from flask import Blueprint, jsonify, redirect, render_template, request
from flask import session as login_session

from sqlalchemy import create_engine, asc
from sqlalchemy.orm import sessionmaker
from database import Base, Invoice, InvoiceItems, Config, Company, dbpath

engine = create_engine(dbpath)
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
session = DBSession()

url = Blueprint('invoice', __name__)


@url.route('/invoice')
def invoice():
	printInvoiceID = request.args.get("print")
	if printInvoiceID == None:
		printInvoiceID = 'None'
	return render_template('invoice.html', printInvoiceID=printInvoiceID)


############################################
############  PURCHASE INVOICE  ############
############################################


@url.route('/invoice/create/purchase')
def createPurchase():
	invoice = session.query(Invoice).filter_by(company_id=login_session['company_id']).filter_by(invoiceType='purchase').order_by(Invoice.sequence.desc()).first()
	if invoice:
		invoiceNumber = "INVP" + str(invoice.sequence + 1);
	else:
		invoiceNumber = "INVP1";
	
	configCustomerNotes = session.query(Config).filter_by(name='customerNotes').first()
	if configCustomerNotes == None:
		customerNotes = ''
	else:
		customerNotes = configCustomerNotes.value
	
	configTerms = session.query(Config).filter_by(name='terms').first()
	if configTerms == None:
		terms = ''
	else:
		terms = configTerms.value
	
	return render_template('invoice_create.html', 
							invoiceNumber=invoiceNumber,
							customerNotes=customerNotes,
							terms=terms,
							type='Purchase')


@url.route('/invoice/get/purchase/filtered')
def getPurchaseFiltered():
	startDate = datetime.datetime.strptime(request.args.get("startDate"), '%d/%m/%Y').date()
	endDate = datetime.datetime.strptime(request.args.get("endDate"), '%d/%m/%Y').date()
	purchaseList = session.query(Invoice).filter_by(company_id=login_session['company_id']).filter_by(invoiceType='purchase').filter(Invoice.invoiceDate>=startDate).filter(Invoice.invoiceDate<=endDate).order_by(Invoice.id.desc()).limit(10).all()
	return jsonify(invoice=[i.serialize for i in purchaseList])


########################################
############  SALE INVOICE  ############
########################################


@url.route('/invoice/create/sale')
def createSale():
	invoice = session.query(Invoice).filter_by(company_id=login_session['company_id']).filter_by(invoiceType='sale').order_by(Invoice.sequence.desc()).first()
	if invoice:
		invoiceNumber = "INV" + str(invoice.sequence + 1);
	else:
		invoiceNumber = "INV1";
	
	configCustomerNotes = session.query(Config).filter_by(name='customerNotes').first()
	if configCustomerNotes == None:
		customerNotes = ''
	else:
		customerNotes = configCustomerNotes.value
	
	configTerms = session.query(Config).filter_by(name='terms').first()
	if configTerms == None:
		terms = ''
	else:
		terms = configTerms.value
	
	return render_template('invoice_create.html', 
							invoiceNumber=invoiceNumber,
							customerNotes=customerNotes,
							terms=terms,
							type='Sale')


@url.route('/invoice/get/sale/filtered')
def getSaleFiltered():
	startDate = datetime.datetime.strptime(request.args.get("startDate"), '%d/%m/%Y').date()
	endDate = datetime.datetime.strptime(request.args.get("endDate"), '%d/%m/%Y').date()
	saleList = session.query(Invoice).filter_by(company_id=login_session['company_id']).filter_by(invoiceType='sale').filter(Invoice.invoiceDate>=startDate).filter(Invoice.invoiceDate<=endDate).order_by(Invoice.id.desc()).limit(10).all()
	return jsonify(invoice=[i.serialize for i in saleList])


######################################
############     CURD     ############
######################################

@url.route('/invoice/create/ajax', methods=['POST'])
def createAjax():
	invoiceType = request.args.get("type")
	data = request.json
	invoice = data['invoice']
	invoiceItemList = data['invoiceItemList']
	invoiceObj = session.query(Invoice).filter_by(company_id=login_session['company_id']).filter_by(invoiceType=invoiceType).order_by(Invoice.sequence.desc()).first()
	if invoiceObj:
		invoiceSeq = invoiceObj.sequence + 1
	else:
		invoiceSeq = 1
	newInvoice = Invoice(invoiceNumber = invoice['invoiceNumber'],
							invoiceType = invoiceType,
							sequence = invoiceSeq,
    						invoiceDate = datetime.datetime.strptime(invoice['invoiceDate'], '%d/%m/%Y').date(),
    						reference = invoice['reference'],
    						adjustmentText = invoice['adjustmentText'],
    						adjustmentAmount = invoice['adjustmentAmount'],
    						customerNotes = invoice['customerNotes'],
    						terms = invoice['terms'],
    						customerName = invoice['customerName'],
    						gstin = invoice['gstin'],
    						billingAddress = invoice['billingAddress'],
    						billingCity = invoice['billingCity'],
    						billingState = invoice['billingState'],
    						billingPincode = invoice['billingPincode'],
    						shippingAddress = invoice['shippingAddress'],
    						shippingCity = invoice['shippingCity'],
    						shippingState = invoice['shippingState'],
    						shippingPincode = invoice['shippingPincode'],
    						subtotal = invoice['subtotal'],
    						cgst = invoice['cgst'],
    						sgst = invoice['sgst'],
    						igst = invoice['igst'],
    						balanceDue = invoice['balanceDue'],
    						company_id = login_session['company_id'])
	session.add(newInvoice)
	session.flush()
	session.refresh(newInvoice)
	
	for invoiceItem in invoiceItemList:
		newInvoiceItem = InvoiceItems(description = invoiceItem['description'],
							itemType = invoiceItem['itemType'],
							hsnCode = invoiceItem['hsnCode'],
							quantity = invoiceItem['quantity'],
							rate = invoiceItem['rate'],
							tax = invoiceItem['tax'],
							cgst = invoiceItem['cgst'],
							sgst = invoiceItem['sgst'],
							igst = invoiceItem['igst'],
							amount = invoiceItem['amount'],
							invoice_id = newInvoice.id)
		session.add(newInvoiceItem)
		session.flush()
		session.refresh(newInvoiceItem)
	
	customerNotes = session.query(Config).filter_by(name='customerNotes').first()
	if customerNotes:
		customerNotes.value = invoice['customerNotes']
		session.flush()
		session.refresh(customerNotes)
	else:
		newCostomerNotes = Config(name='customerNotes', value=invoice['customerNotes'])
		session.add(newCostomerNotes)
		session.flush()
		session.refresh(newCostomerNotes)

	terms = session.query(Config).filter_by(name='terms').first()
	if terms:
		terms.value = invoice['terms']
		session.flush()
		session.refresh(terms)
	else:
		newTerms = Config(name='terms', value=invoice['terms'])
		session.add(newTerms)
		session.flush()
		session.refresh(newTerms)

	session.commit()
	if newInvoice.id > 0:
		return str(newInvoice.id)
	else:
		return "fail"


@url.route('/invoice/get/single/<invoice_id>')
def invoiceGetSingle(invoice_id):
	invoice = session.query(Invoice).filter_by(id=invoice_id).one()
	return jsonify(invoice.serialize);


@url.route('/invoice/get/single/items/<invoice_id>')
def invoiceGetSingleItems(invoice_id):
	invoiceItems = session.query(InvoiceItems).filter_by(invoice_id=invoice_id).all()
	return jsonify(invoiceItems=[i.serialize for i in invoiceItems])


@url.route('/invoice/view/<invoice_id>')
def view(invoice_id):
	invoice = session.query(Invoice).filter_by(id=invoice_id).one()
	company = session.query(Company).filter_by(id=login_session['company_id']).one()
	invoiceItems = session.query(InvoiceItems).filter_by(invoice_id=invoice.id).all()
	showShipping = 'no'
	if invoice.billingAddress != invoice.shippingAddress or invoice.billingCity != invoice.shippingCity or invoice.billingState != invoice.shippingState or invoice.billingPincode != invoice.shippingPincode:
		showShipping = 'yes'
	return render_template('invoice_view.html', 
							invoice=invoice, 
							company=company, 
							invoiceItems=invoiceItems,
							showShipping=showShipping)


@url.route('/invoice/delete/<invoice_id>', methods=['POST'])
def delete(invoice_id):
	invoice = session.query(Invoice).filter_by(id=invoice_id).one()
	if invoice and invoice.company_id == login_session['company_id']:
		session.delete(invoice)
		session.commit()
		return 'true'
	else:
		return 'false'


@url.route('/invoice/edit/<invoice_id>')
def edit(invoice_id):
	if invoice:
		return render_template('invoice_create.html', 
							invoice_id=invoice_id,
							type='edit')
	else:
		return "invalid invoice id";


@url.route('/invoice/edit/ajax', methods=['POST'])
def editAjax():
	data = request.json
	invoice = data['invoice']
	invoiceItemList = data['invoiceItemList']
	invoiceObj = session.query(Invoice).filter_by(id=invoice['id']).one()
	if invoiceObj and invoiceObj.company_id == login_session['company_id']:
		# update invoice details
		invoiceObj.invoiceNumber = invoice['invoiceNumber']
		invoiceObj.invoiceDate = datetime.datetime.strptime(invoice['invoiceDate'], '%d/%m/%Y').date()
		invoiceObj.reference = invoice['reference']
		invoiceObj.adjustmentText = invoice['adjustmentText']
		invoiceObj.adjustmentAmount = invoice['adjustmentAmount']
		invoiceObj.customerNotes = invoice['customerNotes']
		invoiceObj.terms = invoice['terms']
		invoiceObj.customerName = invoice['customerName']
		invoiceObj.gstin = invoice['gstin']
		invoiceObj.billingAddress = invoice['billingAddress']
		invoiceObj.billingCity = invoice['billingCity']
		invoiceObj.billingState = invoice['billingState']
		invoiceObj.billingPincode = invoice['billingPincode']
		invoiceObj.shippingAddress = invoice['shippingAddress']
		invoiceObj.shippingCity = invoice['shippingCity']
		invoiceObj.shippingState = invoice['shippingState']
		invoiceObj.shippingPincode = invoice['shippingPincode']
		invoiceObj.subtotal = invoice['subtotal']
		invoiceObj.cgst = invoice['cgst']
		invoiceObj.sgst = invoice['sgst']
		invoiceObj.igst = invoice['igst']
		invoiceObj.balanceDue = invoice['balanceDue']
		session.flush()
		session.refresh(invoiceObj)
		# delete all previous items
		invoiceItemToDelete = session.query(InvoiceItems).filter_by(invoice_id=invoiceObj.id).all()
		for i in invoiceItemToDelete:
			session.delete(i)
		# create new items
		for invoiceItem in invoiceItemList:
			newInvoiceItem = InvoiceItems(description = invoiceItem['description'],
											itemType = invoiceItem['itemType'],
											hsnCode = invoiceItem['hsnCode'],
											quantity = invoiceItem['quantity'],
											rate = invoiceItem['rate'],
											tax = invoiceItem['tax'],
											cgst = invoiceItem['cgst'],
											sgst = invoiceItem['sgst'],
											igst = invoiceItem['igst'],
											amount = invoiceItem['amount'],
											invoice_id = invoiceObj.id)
			session.add(newInvoiceItem)
			session.flush()
			session.refresh(newInvoiceItem)
		# commit all changes
		session.commit()
		return str(invoiceObj.id)
	else:
		return 'fail'
