#!/usr/bin/python
# -*- coding: utf-8 -*-
from flask import Blueprint, redirect, render_template, request
from flask import session as login_session

from sqlalchemy import create_engine, asc
from sqlalchemy.orm import sessionmaker
from database import Base, Company, dbpath

engine = create_engine(dbpath)
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
session = DBSession()

url = Blueprint('init', __name__)


@url.route('/')
def root():
    # check if any company exit. If it exist, set first one as default in session.
    # else go to init page
    if session.query(Company).count() > 0:
    	company = session.query(Company).order_by(asc(Company.id)).first()
    	login_session['company_id'] = company.id
    	return redirect('/invoice/create/sale')

    return redirect('/init')


@url.route('/init')
def init():
	return render_template('init.html')
