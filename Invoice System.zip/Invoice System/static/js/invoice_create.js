var app = angular.module('invoice_create', ['mgcrea.ngStrap']);

$(document).ready(function() {
	var date = new Date();
	var today = new Date(date.getFullYear(), date.getMonth(), date.getDate());
	var end = new Date(date.getFullYear(), date.getMonth(), date.getDate());

	$('#invoiceDatePicker').datetimepicker({
		defaultDate: today,
		format: 'DD/MM/YYYY'
	});

	$('#dueDatePicker').datetimepicker({
		defaultDate: today,
		format: 'DD/MM/YYYY'
	});
});

app.controller('invoiceController', ['$scope', '$window', 'apiCalls', function invoiceController($scope, $window, apiCalls) {
	
	$scope.invoice = Invoice();

	$scope.partyList = [];
	$scope.itemList = [];
	$scope.invoiceItemList = [InvoiceItem({})];
	$scope.states = States();
	$scope.newItem = Item();
	$scope.newParty = Party();
	$scope.unitOfMeasurement = UnitOfMeasurement();
	
	apiCalls.getAllParty().then(function(data) {
		$.each(data.party, function(i, key){
			$scope.partyList.push(createParty(key));
		});
	});

	apiCalls.getAllItems().then(function(data) {
		$.each(data.items, function(i, key){
			$scope.itemList.push(createItem(key));
		});
	});

	if(type === "edit"){
		apiCalls.getSingleInvoice(invoice_id).then(function(data) {
			$scope.invoice = createInvoice(data);
			$scope.searchParty = $scope.invoice.customerName;
		});
		apiCalls.getSingleInvoiceItems(invoice_id).then(function(data) {
			$scope.invoiceItemList.splice(0, 1);
			$.each(data.invoiceItems, function(i, key){
				$scope.invoiceItemList.push(createInvoiceItem(key));
			});
		});
	}

	$scope.initInvoice = function(){
		alert("hi");
	};

	$scope.fillPartyWithLookup = function(party){
		$scope.searchParty = party;
		$scope.fillParty();
	};

	$scope.fillParty = function(){
		if($scope.searchParty.hasOwnProperty("id")){
			$scope.invoice.customerName = $scope.searchParty.name;
			$scope.invoice.gstin = $scope.searchParty.gstin;
			$scope.invoice.billingAddress = $scope.searchParty.street;
			$scope.invoice.billingCity = $scope.searchParty.city;
			$scope.invoice.billingState = $scope.searchParty.state;
			$scope.invoice.billingPincode = $scope.searchParty.pincode;
			$scope.invoice.shippingAddress = $scope.searchParty.street;
			$scope.invoice.shippingCity = $scope.searchParty.city;
			$scope.invoice.shippingState = $scope.searchParty.state;
			$scope.invoice.shippingPincode = $scope.searchParty.pincode;
		}
		else {
			$scope.invoice.customerName = '';
			$scope.invoice.gstin = '';
			$scope.invoice.billingAddress = '';
			$scope.invoice.billingCity = '';
			$scope.invoice.billingState = '';
			$scope.invoice.billingPincode = '';
			$scope.invoice.shippingAddress = '';
			$scope.invoice.shippingCity = '';
			$scope.invoice.shippingState = '';
			$scope.invoice.shippingPincode = '';
			if($scope.searchParty != ''){
				$.each($scope.partyList, function(i, key){
					if(key.name === $scope.searchParty){
						$scope.invoice.customerName = key.name;
						$scope.invoice.gstin = key.gstin;
						$scope.invoice.billingAddress = key.street;
						$scope.invoice.billingCity = key.city;
						$scope.invoice.billingState = key.state;
						$scope.invoice.billingPincode = key.pincode;
						$scope.invoice.shippingAddress = key.street;
						$scope.invoice.shippingCity = key.city;
						$scope.invoice.shippingState = key.state;
						$scope.invoice.shippingPincode = key.pincode;
						return false;
					}
				});
			}
		}
	};

	$scope.fillInvoiceItem = function(invoiceItem){
		if(invoiceItem.searchItem.hasOwnProperty("id")){
			invoiceItem.description = invoiceItem.searchItem.description;
			invoiceItem.itemType = invoiceItem.searchItem.itemType;
			invoiceItem.hsnCode = invoiceItem.searchItem.hsnCode;
			invoiceItem.rate = invoiceItem.searchItem.rate;
			invoiceItem.tax = invoiceItem.searchItem.tax;
		}
		else {
			invoiceItem.description = '';
			invoiceItem.itemType = 'Services';
			invoiceItem.hsnCode = '';
			invoiceItem.rate = 0;
			invoiceItem.tax = 0;
			if(invoiceItem.searchItem != ''){
				$.each($scope.itemList, function(i, key){
					if(key.description === invoiceItem.searchItem){
						invoiceItem.description = key.description;
						invoiceItem.itemType = key.itemType;
						invoiceItem.hsnCode = key.hsnCode;
						invoiceItem.rate = key.rate;
						invoiceItem.tax = key.tax;
						return false;
					}
				});
			}
		}
	};

	$scope.calculateAmount = function(invoiceItem) {
		var taxableAmount = parseFloat(invoiceItem.quantity) * parseFloat(invoiceItem.rate);
		invoiceItem.igst = (taxableAmount * parseFloat(invoiceItem.tax)) / 100;
		invoiceItem.cgst = parseFloat(invoiceItem.igst) / 2;
		invoiceItem.sgst = parseFloat(invoiceItem.igst) / 2;
		invoiceItem.amount = (taxableAmount + (taxableAmount * parseFloat(invoiceItem.tax)) / 100).toFixed(2);
		return invoiceItem.amount;
	};

	$scope.getTotal = function(){
		var subtotal = 0;
		var cgst = 0;
		var sgst = 0;
		var igst = 0;
		var balanceDue = 0;
		
		for(var i = 0; i < $scope.invoiceItemList.length; i++){
			var invoiceItem = $scope.invoiceItemList[i];
			subtotal = subtotal + (parseFloat(invoiceItem.quantity) * parseFloat(invoiceItem.rate));
			cgst = cgst + invoiceItem.cgst;
			sgst = sgst + invoiceItem.sgst;
			igst = igst + invoiceItem.igst;
			balanceDue = balanceDue + parseFloat(invoiceItem.amount);
		}

		$scope.invoice.subtotal = subtotal.toFixed(2);
		$scope.invoice.cgst = cgst.toFixed(2);
		$scope.invoice.sgst = sgst.toFixed(2);
		$scope.invoice.igst = igst.toFixed(2);
		$scope.invoice.balanceDue = balanceDue.toFixed(2);

		return $scope.invoice.balanceDue;
	};

	$scope.createInvoiceItem = function(){
		$scope.invoiceItemList.push(InvoiceItem({}));
	};

	$scope.createInvoiceItemWithItem = function(item){
		$scope.invoiceItemList.push(createInvoiceItem(item));
	}

	$scope.removeInvoiceItem = function(index){
		$scope.invoiceItemList.splice(index, 1);
	}

	$scope.createInvoice = function(print, type){
		$scope.invoice.invoiceDate = $("#invoiceDatePicker").val();
		$scope.invoice.dueDate = $("#dueDatePicker").val();
		
		if(type === 'edit'){
			apiCalls.updateInvoice($scope.invoice, $scope.invoiceItemList, angular.lowercase(type)).then(function(response) {
				if(response == 'fail'){
					alert("Unable to save invoice");
				}
				else {
					if(print)
						$window.location.href = '/invoice?print=' + response;
					else $window.location.href = '/invoice';
				}
			});
		}
		else
		apiCalls.createInvoice($scope.invoice, $scope.invoiceItemList, angular.lowercase(type)).then(function(response) {
			if(response == 'fail'){
				alert("Unable to save invoice");
			}
			else {
				if(print)
					$window.location.href = '/invoice?print=' + response;
				else $window.location.href = '/invoice';
			}
		});
	};

	$scope.createItemFormSubmit = function(){
		apiCalls.createItem($scope.newItem).then(function(response) {
			if(response == 'fail'){
				alert("Unable to add item at the moment.")
			}
			else {
				$scope.newItem.id = parseInt(response);
				$scope.itemList.push(createItem($scope.newItem));
			}
		});
	};

	$scope.createPartyFormSubmit = function(){
		
		apiCalls.createParty($scope.newParty).then(function(response) {
			if(response == 'fail'){
				alert("Unable to add party at the moment.")
			}
			else {
				$scope.newParty.id = parseInt(response);
				$scope.partyList.push(createParty($scope.newParty));
			}
		});
	};

}]);

app.service('apiCalls', function($http, $q) {	

	this.getAllParty = function () {
		var deferred = $q.defer();
		
		$http({
				method: "GET",
				url: "/party/getAllParty"
			})
			.then(
				function (response) {
					deferred.resolve(response.data);
				},
				function(errResponse){
					deferred.reject(errResponse);
				}
			);

		return deferred.promise;
	}

	this.getAllItems = function () {
		var deferred = $q.defer();
		
		$http({
				method: "GET",
				url: "/inventory/getAllItems"
			})
			.then(
				function (response) {
					deferred.resolve(response.data);
				},
				function(errResponse){
					deferred.reject(errResponse);
				}
			);

		return deferred.promise;
	}

	this.getSingleInvoice = function (invoice_id) {
		var deferred = $q.defer();
		
		$http({
				method: "GET",
				url: "/invoice/get/single/" + invoice_id
			})
			.then(
				function (response) {
					deferred.resolve(response.data);
				},
				function(errResponse){
					deferred.reject(errResponse);
				}
			);

		return deferred.promise;
	}

	this.getSingleInvoiceItems = function (invoice_id) {
		var deferred = $q.defer();
		
		$http({
				method: "GET",
				url: "/invoice/get/single/items/" + invoice_id
			})
			.then(
				function (response) {
					deferred.resolve(response.data);
				},
				function(errResponse){
					deferred.reject(errResponse);
				}
			);

		return deferred.promise;
	}

	this.createInvoice = function (invoice, invoiceItemList, type) {
		var deferred = $q.defer();
		var data = {
			invoice: invoice,
			invoiceItemList: invoiceItemList
		}
		$http.post("/invoice/create/ajax?type="+type, data)
			.then(
				function (response) {
					deferred.resolve(response.data);
				},
				function(errResponse){
					deferred.reject(errResponse);
				}
			);
		return deferred.promise;
	}

	this.updateInvoice = function (invoice, invoiceItemList) {
		var deferred = $q.defer();
		var data = {
			invoice: invoice,
			invoiceItemList: invoiceItemList
		}
		$http.post("/invoice/edit/ajax", data)
			.then(
				function (response) {
					deferred.resolve(response.data);
				},
				function(errResponse){
					deferred.reject(errResponse);
				}
			);
		return deferred.promise;
	}

	this.createItem = function (item) {
		var deferred = $q.defer();
		
		$http.post("/inventory/createItem", item)
			.then(
				function (response) {
					deferred.resolve(response.data);
				},
				function(errResponse){
					deferred.reject(errResponse);
				}
			);
		return deferred.promise;
	}
	
	this.createParty = function (party) {
		var deferred = $q.defer();
		
		$http.post("/party/createParty", party)
			.then(
				function (response) {
					deferred.resolve(response.data);
				},
				function(errResponse){
					deferred.reject(errResponse);
				}
			);
		return deferred.promise;
	}
});