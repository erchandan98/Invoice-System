var init = angular.module('init', []);


init.controller('initController', ['$scope', '$window', 'apiCalls', function initController($scope, $window, apiCalls) {

	$scope.data = Company();
	
	$scope.createCompany = function(){
		apiCalls.createCompany($scope.data).then(function(response) {
			if(response == 'fail'){
				alert("Unable to create company. Please try again.");
			}
			else{
				$window.location.href = '/invoice/create/sale';
			}
		});
	};

	$scope.states = States();
	
}]);

init.service('apiCalls', function($http, $q) {	

	this.createCompany = function (data) {
		var deferred = $q.defer();
		
		$http.post("/company/create", data)
			.then(
    			function (response) {
    				deferred.resolve(response.data);
    			},
    			function(errResponse){
    				deferred.reject(errResponse);
    			}
        	);
		return deferred.promise;
	}
	
});