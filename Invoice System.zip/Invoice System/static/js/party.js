var app = angular.module('party', []);  

app.controller('searchController', function searchController($scope, partyData, apiCalls){

	$scope.searchText = '';

	$scope.search = function(){
		if($scope.searchText === ''){
			partyData.setBoxTitle("Top Party");
			partyData.clearPartyList();
			apiCalls.getTopParty().then(function(data) {
				$.each(data.party, function(i, key){
					partyData.addToPartyList(key);
				});
			});
		}
		else {
			partyData.setBoxTitle("Search Results");
			partyData.clearPartyList();
			apiCalls.getSearchParty($scope.searchText).then(function(data) {
				$.each(data.party, function(i, key){
					partyData.addToPartyList(key);
				});
			});
		}
	}

});

app.controller('createPartyController', function createPartyController($scope, partyData, apiCalls){

	$scope.newParty = Party();

	$scope.createPartyFormSubmit = function(){
		
		apiCalls.createParty($scope.newParty).then(function(response) {
			if(response == 'fail'){
				alert("Unable to add party at the moment.")
			}
			else {
				if(partyData.getLength() == 13)
					partyData.removeLast();
				$scope.newParty.id = parseInt(response);
				partyData.addToPartyListStart($scope.newParty);
			}
		});
	};

	$scope.states = States();
});

app.controller('partyController', function partyController($scope, partyData, apiCalls){

	partyData.setBoxTitle("Top Party");

	$scope.partyList = partyData.getPartyList();
	$scope.boxTitle = partyData.getBoxTitle;
	$scope.partyView = false;
	$scope.singleParty = null;
	$scope.editPartyView = false;
	$scope.editPartyObj = null;
	$scope.states = States();

	apiCalls.getTopParty().then(function(data) {
		$.each(data.party, function(i, key){
			partyData.addToPartyList(key);
		});
	});

	$scope.backToList = function(){
		$scope.partyView = false;
		$scope.singleParty = null;
		partyData.setBoxTitle("Top Party");
	};

	$scope.backToSingleParty = function(){
		$scope.partyView = true;
		$scope.editPartyView = false;
		$scope.editPartyObj = null;
	};

	$scope.openParty = function(party){
		$scope.partyView = true;
		$scope.singleParty = party;
		partyData.setBoxTitle("Single Party View");
	};

	$scope.editParty = function(){
		$scope.partyView = "editItem";
		$scope.editPartyView = true;
		$scope.editPartyObj = createParty($scope.singleParty);
	};

	$scope.editPartyFormSubmit = function(){
		apiCalls.editParty($scope.editPartyObj).then(function(response) {
			if(response == 'false'){
				alert("Unable to edit party at the moment.")
			}
			else {
				$scope.singleParty.partyType = $scope.editPartyObj.partyType,
				$scope.singleParty.name = $scope.editPartyObj.name;
				$scope.singleParty.contactPerson = $scope.editPartyObj.contactPerson;
				$scope.singleParty.gstin = $scope.editPartyObj.gstin;
				$scope.singleParty.contactNumber = $scope.editPartyObj.contactNumber;
				$scope.singleParty.street = $scope.editPartyObj.street;
				$scope.singleParty.city = $scope.editPartyObj.city;
				$scope.singleParty.state = $scope.editPartyObj.state;
				$scope.singleParty.pincode = $scope.editPartyObj.pincode;
				$scope.singleParty.emailID = $scope.editPartyObj.emailID;
				$scope.singleParty.landlineNo = $scope.editPartyObj.landlineNo;
				$scope.backToSingleParty();
			}
		});
	};

	$scope.deleteParty = function(){
		apiCalls.deleteParty($scope.singleParty).then(function(response) {
			if(response == 'false'){
				alert("Unable to delete party at the moment.")
			}
			else {
				partyData.removeParty($scope.singleParty);
				$scope.partyView = false;
				$scope.singleParty = null;
				partyData.setBoxTitle("Top Party");
			}
		});
	};

});

app.service('partyData', function () {
    var boxTitle = '';
    var partyList = [];
    
    this.clearPartyList = function () {
		partyList.splice(0,partyList.length);
	}

    this.getPartyList = function () {
        return partyList;
    };
    
    this.addToPartyList = function(value) {
    	partyList.push(createParty(value));
    };

    this.addToPartyListStart = function(value) {
    	partyList.unshift(createParty(value));
    };

    this.removeLast = function(){
    	partyList.pop();
    };

    this.removeParty = function(value){
    	for(var i = partyList.length - 1; i >= 0; i--) {
    		if(partyList[i].id === value.id) {
    			partyList.splice(i, 1);
    			break;
    		}
    	}
    };

    this.getLength = function(){
    	return partyList.length;
    }

    this.getBoxTitle = function(){
    	return boxTitle;
    };

    this.setBoxTitle = function(value) {
    	boxTitle = value;
    };

});

app.service('apiCalls', function($http, $q) {	
	
	this.getTopParty = function () {
		var deferred = $q.defer();
		
		$http({
				method: "GET",
				url: "/party/getTopParty"
			})
        	.then(
    			function (response) {
    				deferred.resolve(response.data);
    			},
    			function(errResponse){
    				deferred.reject(errResponse);
    			}
        	);

		return deferred.promise;
	}

	this.getSearchParty = function (searchText) {
		var deferred = $q.defer();
		
		$http({
				method: "GET",
				url: "/party/getSearchParty",
				params: {searchText: searchText}
			})
			.then(
				function (response) {
					deferred.resolve(response.data);
				},
				function(errResponse){
					deferred.reject(errResponse);
				}
			);
		return deferred.promise;
	}

	this.createParty = function (party) {
		var deferred = $q.defer();
		
		$http.post("/party/createParty", party)
			.then(
    			function (response) {
    				deferred.resolve(response.data);
    			},
    			function(errResponse){
    				deferred.reject(errResponse);
    			}
        	);
		return deferred.promise;
	}

	this.editParty = function (party) {
		var deferred = $q.defer();
		
		$http.post("/party/" + party.id + "/edit", party)
			.then(
    			function (response) {
    				deferred.resolve(response.data);
    			},
    			function(errResponse){
    				deferred.reject(errResponse);
    			}
        	);
		return deferred.promise;
	}

	this.deleteParty = function (party) {
		var deferred = $q.defer();
		
		$http.post("/party/" + party.id + "/delete")
			.then(
				function (response) {
					deferred.resolve(response.data);
				},
				function(errResponse){
					deferred.reject(errResponse);
				}
			);
		return deferred.promise;
	}
	
});