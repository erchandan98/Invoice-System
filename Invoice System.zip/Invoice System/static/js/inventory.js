var app = angular.module('inventory', []);  

app.controller('searchController', function searchController($scope, itemData, apiCalls){

	$scope.searchText = '';

	$scope.search = function(){
		if($scope.searchText === ''){
			itemData.setBoxTitle("Top Items");
			itemData.clearItemList();
			apiCalls.getTopItems().then(function(data) {
				$.each(data.items, function(i, key){
					itemData.addToItemList(key);
				});
			});
		}
		else {
			itemData.setBoxTitle("Search Results");
			itemData.clearItemList();
			apiCalls.getSearchItems($scope.searchText).then(function(data) {
				$.each(data.items, function(i, key){
					itemData.addToItemList(key);
				});
			});
		}
	}

});

app.controller('createItemController', function createItemController($scope, itemData, apiCalls){

	$scope.newItem = Item();
	$scope.unitOfMeasurement = UnitOfMeasurement();

	$scope.createItemFormSubmit = function(){
		
		apiCalls.createItem($scope.newItem).then(function(response) {
			if(response == 'fail'){
				alert("Unable to add item at the moment.")
			}
			else {
				if(itemData.getLength() == 8)
					itemData.removeLast();
				$scope.newItem.id = parseInt(response);
				itemData.addToItemListStart($scope.newItem);
			}
		});
	};
});

app.controller('itemController', function itemController($scope, itemData, apiCalls){

	itemData.setBoxTitle("Top Items");

	$scope.itemList = itemData.getItemList();
	$scope.boxTitle = itemData.getBoxTitle;
	$scope.itemView = false;
	$scope.singleItem = null;
	$scope.editItemView = false;
	$scope.editItemObj = null;

	apiCalls.getTopItems().then(function(data) {
		$.each(data.items, function(i, key){
			itemData.addToItemList(key);
		});
	});

	$scope.backToList = function(){
		$scope.itemView = false;
		$scope.singleItem = null;
		itemData.setBoxTitle("Top Items");
	};

	$scope.backToSingleItem = function(){
		$scope.itemView = true;
		$scope.editItemView = false;
		$scope.editItemObj = null;
	};

	$scope.openItem = function(item){
		$scope.itemView = true;
		$scope.singleItem = item;
		itemData.setBoxTitle("Single Item View");
	};

	$scope.editItem = function(){
		$scope.itemView = "editItem";
		$scope.editItemView = true;
		$scope.editItemObj = createItem($scope.singleItem);
	};

	$scope.editItemFormSubmit = function(){
		apiCalls.editItem($scope.editItemObj).then(function(response) {
			if(response == 'false'){
				alert("Unable to edit item at the moment.")
			}
			else {
				$scope.singleItem.description = $scope.editItemObj.description;
				$scope.singleItem.itemType = $scope.editItemObj.itemType;
				$scope.singleItem.hsnCode = $scope.editItemObj.hsnCode;
				$scope.singleItem.rate = $scope.editItemObj.rate;
				$scope.singleItem.tax = $scope.editItemObj.tax;
				$scope.singleItem.unitOfMeasurement = $scope.editItemObj.unitOfMeasurement;
				$scope.singleItem.notes = $scope.editItemObj.notes;
				$scope.backToSingleItem();
			}
		});
	};

	$scope.deleteItem = function(){
		apiCalls.deleteItem($scope.singleItem).then(function(response) {
			if(response == 'false'){
				alert("Unable to delete item at the moment.")
			}
			else {
				itemData.removeItem($scope.singleItem);
				$scope.itemView = false;
				$scope.singleItem = null;
				itemData.setBoxTitle("Top Items");
			}
		});
	};

});

app.service('itemData', function () {

	var boxTitle = '';
	var itemList = [];

	this.clearItemList = function () {
		itemList.splice(0,itemList.length);
	}

    this.getItemList = function () {
        return itemList;
    };
    
    this.addToItemList = function(value) {
    	itemList.push(createItem(value));
    };

    this.addToItemListStart = function(value) {
    	itemList.unshift(createItem(value));
    };

    this.removeLast = function(){
    	itemList.pop();
    };

    this.removeItem = function(value){
    	for(var i = itemList.length - 1; i >= 0; i--) {
    		if(itemList[i].id === value.id) {
    			itemList.splice(i, 1);
    			break;
    		}
    	}
    };

    this.getLength = function(){
    	return itemList.length;
    };

    this.getBoxTitle = function(){
    	return boxTitle;
    };

    this.setBoxTitle = function(value) {
    	boxTitle = value;
    };

});

app.service('apiCalls', function($http, $q) {	
	
	this.getTopItems = function () {
		var deferred = $q.defer();
		
		$http({
				method: "GET",
				url: "/inventory/getTopItems"
			})
			.then(
				function (response) {
					deferred.resolve(response.data);
				},
				function(errResponse){
					deferred.reject(errResponse);
				}
			);
		return deferred.promise;
	}

	this.getSearchItems = function (searchText) {
		var deferred = $q.defer();
		
		$http({
				method: "GET",
				url: "/inventory/getSearchItems",
				params: {searchText: searchText}
			})
			.then(
				function (response) {
					deferred.resolve(response.data);
				},
				function(errResponse){
					deferred.reject(errResponse);
				}
			);
		return deferred.promise;
	}

	this.createItem = function (item) {
		var deferred = $q.defer();
		
		$http.post("/inventory/createItem", item)
			.then(
    			function (response) {
    				deferred.resolve(response.data);
    			},
    			function(errResponse){
    				deferred.reject(errResponse);
    			}
        	);
		return deferred.promise;
	}

	this.editItem = function (item) {
		var deferred = $q.defer();
		
		$http.post("/inventory/item/" + item.id + "/edit", item)
			.then(
    			function (response) {
    				deferred.resolve(response.data);
    			},
    			function(errResponse){
    				deferred.reject(errResponse);
    			}
        	);
		return deferred.promise;
	}

	this.deleteItem = function (item) {
		var deferred = $q.defer();
		
		$http.post("/inventory/item/" + item.id + "/delete")
			.then(
    			function (response) {
    				deferred.resolve(response.data);
    			},
    			function(errResponse){
    				deferred.reject(errResponse);
    			}
        	);
		return deferred.promise;
	}
	
});