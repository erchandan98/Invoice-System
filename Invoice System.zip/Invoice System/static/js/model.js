function States() {
	var states = [
		{'name': 'Andaman and Nicobar Islands','tinFirstTwo': 35,'code': 'AN'},
		{'name': 'Andhra Pradesh','tinFirstTwo': 28,'code': 'AP'},
		//{'name': 'Andhra Pradesh (New)','tinFirstTwo': 37,'code': 'AD'},
		{'name': 'Arunachal Pradesh','tinFirstTwo': 12,'code': 'AR'},
		{'name': 'Assam','tinFirstTwo': 18,'code': 'AS'},
		{'name': 'Bihar','tinFirstTwo': 10,'code': 'BH'},
		{'name': 'Chandigarh','tinFirstTwo': 04,'code': 'CH'},
		{'name': 'Chattisgarh','tinFirstTwo': 22,'code': 'CT'},
		{'name': 'Dadra and Nagar Haveli','tinFirstTwo': 26,'code': 'DN'},
		{'name': 'Daman and Diu','tinFirstTwo': 25,'code': 'DD'},
		{'name': 'Delhi','tinFirstTwo': 07,'code': 'DL'},
		{'name': 'Goa','tinFirstTwo': 30,'code': 'GA'},
		{'name': 'Gujarat','tinFirstTwo': 24,'code': 'GJ'},
		{'name': 'Haryana','tinFirstTwo': 06,'code': 'HR'},
		{'name': 'Himachal Pradesh','tinFirstTwo': 02,'code': 'HP'},
		{'name': 'Jammu and Kashmir','tinFirstTwo': 01,'code': 'JK'},
		{'name': 'Jharkhand','tinFirstTwo': 20,'code': 'JH'},
		{'name': 'Karnataka','tinFirstTwo': 29,'code': 'KA'},
		{'name': 'Kerala','tinFirstTwo': 32,'code': 'KL'},
		{'name': 'Lakshadweep Islands','tinFirstTwo': 31,'code': 'LD'},
		{'name': 'Madhya Pradesh','tinFirstTwo': 23,'code': 'MP'},
		{'name': 'Maharashtra','tinFirstTwo': 27,'code': 'MH'},
		{'name': 'Manipur','tinFirstTwo': 14,'code': 'MN'},
		{'name': 'Meghalaya','tinFirstTwo': 17,'code': 'ME'},
		{'name': 'Mizoram','tinFirstTwo': 15,'code': 'MI'},
		{'name': 'Nagaland','tinFirstTwo': 13,'code': 'NL'},
		{'name': 'Odisha','tinFirstTwo': 21,'code': 'OR'},
		{'name': 'Pondicherry','tinFirstTwo': 34,'code': 'PY'},
		{'name': 'Punjab','tinFirstTwo': 03,'code': 'PB'},
		{'name': 'Rajasthan','tinFirstTwo': 08,'code': 'RJ'},
		{'name': 'Sikkim','tinFirstTwo': 11,'code': 'SK'},
		{'name': 'Tamil Nadu','tinFirstTwo': 33,'code': 'TN'},
		{'name': 'Telangana','tinFirstTwo': 36,'code': 'TS'},
		{'name': 'Tripura','tinFirstTwo': 16,'code': 'TR'},
		{'name': 'Uttar Pradesh','tinFirstTwo': 09,'code': 'UP'},
		{'name': 'Uttarakhand','tinFirstTwo': 05,'code': 'UT'},
		{'name': 'West Bengal','tinFirstTwo': 19,'code': 'WB'}
	];
	return states;
}

function UnitOfMeasurement() {
	var unitOfMeasurement = [
		{'name':'None', 'value':''},
		{'name':'boxes', 'value':'boxes'},
		{'name':'cm', 'value':'cm'},
		{'name':'crates', 'value':'crates'},
		{'name':'cu mtr', 'value':'cu mtr'},
		{'name':'gm', 'value':'gm'},
		{'name':'kg', 'value':'kg'},
		{'name':'ltr', 'value':'ltr'},
		{'name':'metric ton', 'value':'metric ton'},
		{'name':'ml', 'value':'ml'},
		{'name':'mm', 'value':'mm'},
		{'name':'mtr', 'value':'mtr'},
		{'name':'pallets', 'value':'pallets'},
		{'name':'pieces', 'value':'pieces'},
		{'name':'pkts', 'value':'pkts'},
		{'name':'sheets', 'value':'sheets'},
		{'name':'sq.cm', 'value':'sq.cm'},
		{'name':'sq.m', 'value':'sq.m'}
	];
	return unitOfMeasurement;
}

function Company(){
	var company = {
		partyName: '',
		street: '',
		city: '',
		state: 'Delhi',
		pincode: '',
		gstRegistered: 'No',
		gstin: '',
		compositionScheme: 'No',
		schemePercentage: '1'
	};
	return company;
}

function createCompany(data){
	var company = Company();
	company.partyName = data.partyName;
	company.street = data.street;
	company.city = data.city;
	company.state = data.state;
	company.pincode = data.pincode;
	company.gstRegistered = data.gstRegistered;
	company.gstin = data.gstin;
	company.compositionScheme = data.compositionScheme;
	company.schemePercentage = data.schemePercentage;
	return company;
}

function Item(){
	var item = {
		id: '',
		description: '',
		itemType: 'Goods',
		hsnCode: '',
		rate: 0,
		tax: '1.5',
		unitOfMeasurement: '',
		notes: ''
	};
	return item;
}

function createItem(data){
	var item = Item();
	item.id = data.id;
	item.description = data.description;
	item.itemType = data.itemType;
	item.hsnCode = data.hsnCode;
	item.rate = data.rate;
	item.tax = String(data.tax);
	item.unitOfMeasurement = data.unitOfMeasurement;
	item.notes = data.notes;
	return item;
}

function Party(){
	var party = {
		id: '',
		partyType: 'Business',
    	name: '',
    	contactPerson: '',
    	gstin: '',
    	contactNumber: '',
    	street: '',
    	city: '',
    	state: 'Delhi',
    	pincode: '',
    	emailID: '',
    	landlineNo: ''
	};

	return party;
}

function createParty(data){
	var party = Party();
	party.id = data.id;
	party.partyType = data.partyType,
	party.name = data.name;
	party.contactPerson = data.contactPerson;
	party.gstin = data.gstin;
	party.contactNumber = data.contactNumber;
	party.street = data.street;
	party.city = data.city;
	party.state = data.state;
	party.pincode = data.pincode;
	party.emailID = data.emailID;
	party.landlineNo = data.landlineNo;
	return party;
}

function Invoice(){
	var invoice = {
		id: '',
		invoiceType: '',
		sequence: '',
		invoiceNumber: '',
		invoiceDate: '',
		reference: '',
		dueDate: '',
		adjustmentText: '',
		adjustmentAmount: 0,
		customerNotes: '',
		terms: '',
		customerName: '',
		gstin: '',
		billingAddress: '',
		billingCity: '',
		billingState: '',
		billingPincode: '',
		shippingAddress: '',
		shippingCity: '',
		shippingState: '',
		shippingPincode: '',
		subtotal: 0,
		cgst: 0,
		sgst: 0,
		igst: 0,
		balanceDue: 0
	}
	return invoice;
}

function createInvoice(data){
	var invoice = Invoice();
	invoice.id = data.id;
	invoice.invoiceType = data.invoiceType;
	invoice.sequence = data.sequence;
	invoice.invoiceNumber = data.invoiceNumber;
	invoice.invoiceDate = data.invoiceDate;
	invoice.reference = data.reference;
	invoice.dueDate = data.dueDate;
	invoice.adjustmentText = data.adjustmentText;
	invoice.adjustmentAmount = data.adjustmentAmount;
	invoice.customerNotes = data.customerNotes;
	invoice.terms = data.terms;
	invoice.customerName = data.customerName;
	invoice.gstin = data.gstin;
	invoice.billingAddress = data.billingAddress;
	invoice.billingCity = data.billingCity;
	invoice.billingState = data.billingState;
	invoice.billingPincode = data.billingPincode;
	invoice.shippingAddress = data.shippingAddress;
	invoice.shippingCity = data.shippingCity;
	invoice.shippingState = data.shippingState;
	invoice.shippingPincode = data.shippingPincode;
	invoice.subtotal = data.subtotal;
	invoice.cgst = data.cgst;
	invoice.sgst = data.sgst;
	invoice.igst = data.igst;
	invoice.balanceDue = data.balanceDue;
	return invoice;
}

function InvoiceItem(){
	var invoiceItem = {
		searchItem: '',
		id: '',
		description: "",
		itemType: 'Services',
		hsnCode: "",
		quantity: 0,
		rate: 0,
		tax: "0",
		cgst: 0,
		sgst: 0,
		igst: 0,
		amount: 0
	};
	return invoiceItem;
}

function createInvoiceItem(data){
	var invoiceItem = InvoiceItem();
	invoiceItem.searchItem = data.description;
	invoiceItem.id = data.id;
	invoiceItem.description = data.description;
	invoiceItem.itemType = data.itemType;
	invoiceItem.hsnCode = data.hsnCode;
	if(data.hasOwnProperty('quantity'))
		invoiceItem.quantity = data.quantity;
	else invoiceItem.quantity = 0;
	invoiceItem.rate = data.rate;
	invoiceItem.tax = String(data.tax);
	invoiceItem.cgst = data.cgst;
	invoiceItem.sgst = data.sgst;
	invoiceItem.igst = data.igst;
	invoiceItem.amount = data.amount;
	return invoiceItem;
}