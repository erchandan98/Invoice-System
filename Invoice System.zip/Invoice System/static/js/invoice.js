var app = angular.module('invoice', []);  

$(function() {

    var start = moment().subtract(29, 'days');
    var end = moment();

    $('input[name="daterange"]').daterangepicker({
        startDate: start,
        endDate: end,
        locale: {
            format: 'DD/MM/YYYY'
        }
    });

});

app.controller('searchController', function searchController($scope, invoiceData, apiCalls){

	$scope.searchText = '';
	$scope.filterDate = '';

	$scope.filter = function(){
		var date = $scope.filterDate.split(" - ");

		invoiceData.clearSaleList();
		apiCalls.getFilteredSaleInvoice(date).then(function(data) {
			$.each(data.invoice, function(i, key){
				invoiceData.addToSaleList(key);
			});
		});

		invoiceData.clearPurchaseList();
		apiCalls.getFilteredPurchaseInvoice(date).then(function(data) {
			$.each(data.invoice, function(i, key){
				invoiceData.addToPurchaseList(key);
			});
		});

	}

	$scope.search = function(){
		// if($scope.searchText === ''){
		// 	partyData.setBoxTitle("Top Party");
		// 	partyData.clearPartyList();
		// 	apiCalls.getTopParty().then(function(data) {
		// 		$.each(data.party, function(i, key){
		// 			partyData.addToPartyList(key);
		// 		});
		// 	});
		// }
		// else {
		// 	partyData.setBoxTitle("Search Results");
		// 	partyData.clearPartyList();
		// 	apiCalls.getSearchParty($scope.searchText).then(function(data) {
		// 		$.each(data.party, function(i, key){
		// 			partyData.addToPartyList(key);
		// 		});
		// 	});
		// }
	}

});

app.controller('invoiceController', function invoiceController($scope, invoiceData, apiCalls, $window){

	$scope.saleList = invoiceData.getSaleList();
	$scope.purchaseList = invoiceData.getPurchaseList();

	$scope.printInvoice = function(invoice){
		$window.open('/invoice/view/' + invoice.id, '_blank');
	};

	$scope.deleteInvoice = function(invoice, type){
		apiCalls.deleteInvoice(invoice).then(function(response) {
			if(response == 'false'){
				alert("Unable to delete invoice at the moment.")
			}
			else {
				if(type === 'sale')
					invoiceData.removeInvoiceFromSaleList(invoice);
				else if(type === 'purchase')
					invoiceData.removeInvoiceFromPurchaseList(invoice)
			}
		});
	};

	$scope.editInvoice = function(invoice){
		$window.location.href = '/invoice/edit/' + invoice.id;
	};

});


app.directive('ngConfirmClick', [function(){
	return {
		link: function (scope, element, attr) {
			var msg = attr.ngConfirmClick || "Are you sure?";
			var clickAction = attr.confirmedClick;
			element.bind('click',function (event) {
				if ( window.confirm(msg) ) {
					scope.$eval(clickAction)
				}
			});
		}
	};
}])

app.service('invoiceData', function () {
	
	var saleList = [];
	var purchaseList = []
	
	this.getLengthOfSaleList = function(){
		return saleList.length;
	}

	this.clearSaleList = function () {
		saleList.splice(0,saleList.length);
	}

	this.getSaleList = function () {
		return saleList;
	};

	this.addToSaleList = function(value) {
		saleList.push(createInvoice(value));
	};

	this.addToSaleListStart = function(value) {
		saleList.unshift(createInvoice(value));
	};

	this.removeLastFromSaleList = function(){
		saleList.pop();
	};

	this.removeInvoiceFromSaleList = function(value){
		for(var i = saleList.length - 1; i >= 0; i--) {
			if(saleList[i].id === value.id) {
				saleList.splice(i, 1);
				break;
			}
		}
	};

	this.getLengthOfPurchaseList = function(){
		return purchaseList.length;
	}

	this.clearPurchaseList = function () {
		purchaseList.splice(0,purchaseList.length);
	}

	this.getPurchaseList = function () {
		return purchaseList;
	};

	this.addToPurchaseList = function(value) {
		purchaseList.push(createInvoice(value));
	};

	this.addToPurchaseListStart = function(value) {
		purchaseList.unshift(createInvoice(value));
	};

	this.removeLastFromPurchaseList = function(){
		purchaseList.pop();
	};

	this.removeInvoiceFromPurchaseList = function(value){
		for(var i = purchaseList.length - 1; i >= 0; i--) {
			if(purchaseList[i].id === value.id) {
				purchaseList.splice(i, 1);
				break;
			}
		}
	};

});

app.service('apiCalls', function($http, $q) {

	this.getFilteredSaleInvoice = function (date) {
		var deferred = $q.defer();

		$http({
			method: "GET",
			url: "/invoice/get/sale/filtered",
			params: {startDate: date[0], endDate: date[1]}
		})
		.then(
			function (response) {
				deferred.resolve(response.data);
			},
			function(errResponse){
				deferred.reject(errResponse);
			}
		);

		return deferred.promise;
	}

	this.getFilteredPurchaseInvoice = function (date) {
		var deferred = $q.defer();

		$http({
			method: "GET",
			url: "/invoice/get/purchase/filtered",
			params: {startDate: date[0], endDate: date[1]}
		})
		.then(
			function (response) {
				deferred.resolve(response.data);
			},
			function(errResponse){
				deferred.reject(errResponse);
			}
		);

		return deferred.promise;
	}

	this.deleteInvoice = function (invoice) {
		var deferred = $q.defer();
		
		$http.post("/invoice/delete/" + invoice.id)
			.then(
				function (response) {
					deferred.resolve(response.data);
				},
				function(errResponse){
					deferred.reject(errResponse);
				}
			);
		return deferred.promise;
	}
});