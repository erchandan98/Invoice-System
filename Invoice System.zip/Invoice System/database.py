#!/usr/bin/python
# -*- coding: utf-8 -*-
import platform, os
from sqlalchemy import Column, ForeignKey, Integer, String, func, DateTime, Float, Date
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy import create_engine

Base = declarative_base()

class Company(Base):

    __tablename__ = 'company'

    id = Column(Integer, primary_key=True)
    partyName = Column(String(100), nullable=False)
    street = Column(String(1000), nullable=False)
    city = Column(String(100), nullable=False)
    state = Column(String(100), nullable=False)
    pincode = Column(Integer, nullable=False)
    gstRegistered = Column(String(10), default="No")
    gstin = Column(String(15), default="")
    compositionScheme = Column(String(10), default='No')
    schemePercentage = Column(Integer, default=0)
    time_created = Column(DateTime(timezone=True),
                          server_default=func.now())
    time_updated = Column(DateTime(timezone=True), onupdate=func.now())

    @property
    def serialize(self):
        """Return object data in easily serializeable format"""

        return {
            'id': self.id, 
            'partyName': self.partyName, 
            'city': self.city,
            'state': self.state,
            'pincode': self.pincode,
            'gstRegistered': self.gstRegistered,
            'gstRegistered': self.gstRegistered,
            'gstin': self.gstin,
            'compositionScheme': self.compositionScheme,
            'schemePercentage': self.schemePercentage,
            'schemePercentage': self.schemePercentage,
        }


class Item(Base):

    __tablename__ = 'item'

    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('company.id'), index=True)
    description = Column(String(1000), nullable=False, index=True)
    itemType = Column(String(50), default="Goods") 
    hsnCode = Column(String(100), default="")
    rate = Column(Integer, default=0)
    tax = Column(Float, default=0)
    unitOfMeasurement = Column(String(100), default="")
    notes = Column(String(2000), default="")
    time_created = Column(DateTime(timezone=True),
                          server_default=func.now())
    time_updated = Column(DateTime(timezone=True), onupdate=func.now())
    company = relationship(Company)

    @property
    def serialize(self):
        """Return object data in easily serializeable format"""

        return {
            'id': self.id,
            'itemType': self.itemType,
            'description': self.description,
            'hsnCode': self.hsnCode,
            'rate': self.rate,
            'tax': self.tax,
            'unitOfMeasurement': self.unitOfMeasurement,
            'notes': self.notes
        }


class Party(Base):

    __tablename__ = 'party'

    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('company.id'), index=True)
    name = Column(String(200), nullable=False, index=True)
    partyType = Column(String(100), nullable=False)
    contactPerson = Column(String(200), default="")
    gstin = Column(String(15), default="")
    contactNumber = Column(String(15), default="")
    street = Column(String(1000), default="")
    city = Column(String(50), default="")
    state = Column(String(50), nullable=False)
    pincode = Column(String(50), default="")
    emailID = Column(String(200), default="")
    landlineNo = Column(String(50), default="")
    time_created = Column(DateTime(timezone=True),
                          server_default=func.now())
    time_updated = Column(DateTime(timezone=True), onupdate=func.now())
    company = relationship(Company)

    @property
    def serialize(self):
        """Return object data in easily serializeable format"""

        return {
            'id': self.id,
            'company_id': self.company_id,
            'partyType': self.partyType,
            'name': self.name,
            'contactPerson': self.contactPerson,
            'gstin': self.gstin,
            'contactNumber': self.contactNumber,
            'street': self.street,
            'city': self.city,
            'state': self.state,
            'pincode': self.pincode,
            'emailID': self.emailID,
            'landlineNo': self.landlineNo,
            'time_created': self.time_created,
            'time_updated': self.time_updated
        }


class Invoice(Base):

    __tablename__ = "invoice"

    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('company.id'), index=True)
    invoiceType = Column(String(50), nullable=False, index=True)
    sequence = Column(Integer, nullable=False)
    invoiceNumber = Column(String(50), nullable=False)
    invoiceDate = Column(Date, nullable=False)
    dueData = Column(String(20), default="")
    reference = Column(String(100), default="")
    adjustmentText = Column(String(100), default="")
    adjustmentAmount = Column(Integer, default=0)
    customerNotes = Column(String(2000), default="")
    terms = Column(String(2000), default="")
    customerName = Column(String(100), nullable=False)
    gstin = Column(String(15), default="")
    billingAddress = Column(String(1000), nullable=False)
    billingCity = Column(String(100), nullable=False)
    billingState = Column(String(100), nullable=False)
    billingPincode = Column(Integer, nullable=False)
    shippingAddress = Column(String(1000), nullable=False)
    shippingCity = Column(String(100), nullable=False)
    shippingState = Column(String(100), nullable=False)
    shippingPincode = Column(Integer, nullable=False)
    subtotal = Column(Float, default=0)
    cgst = Column(Float, default=0)
    sgst = Column(Float, default=0)
    igst = Column(Float, default=0)
    balanceDue = Column(Float, default=0)
    time_created = Column(DateTime(timezone=True),
                          server_default=func.now())
    time_updated = Column(DateTime(timezone=True), onupdate=func.now())
    company = relationship(Company)

    @property
    def serialize(self):
        """Return object data in easily serializeable format"""

        return {
            'id': self.id,
            'company_id': self.company_id,
            'invoiceType': self.invoiceType,
            'sequence': self.sequence,
            'invoiceNumber': self.invoiceNumber,
            'invoiceDate': self.invoiceDate.strftime('%d/%m/%Y'),
            'dueData': self.dueData,
            'reference': self.reference,
            'adjustmentText': self.adjustmentText,
            'adjustmentAmount': self.adjustmentAmount,
            'customerNotes': self.customerNotes,
            'terms': self.terms,
            'customerName': self.customerName,
            'gstin': self.gstin,
            'billingAddress': self.billingAddress,
            'billingCity': self.billingCity,
            'billingState': self.billingState,
            'billingPincode': self.billingPincode,
            'shippingAddress': self.shippingAddress,
            'shippingCity': self.shippingCity,
            'shippingState': self.shippingState,
            'shippingPincode': self.shippingPincode,
            'subtotal': self.subtotal,
            'cgst': self.cgst,
            'sgst': self.sgst,
            'igst': self.igst,
            'balanceDue': self.balanceDue
        }


class InvoiceItems(Base):

    __tablename__ = "invoiceItems"

    id = Column(Integer, primary_key=True)
    invoice_id = Column(Integer, ForeignKey('invoice.id'), index=True)
    description = Column(String(200), nullable=False)
    itemType = Column(String(50), default="Services") 
    hsnCode = Column(String(10), default="")
    quantity = Column(Integer, default=0)
    rate = Column(Integer, default=0)
    tax = Column(Float, default=0)
    cgst = Column(Float, default=0)
    sgst = Column(Float, default=0)
    igst = Column(Float, default=0)
    amount = Column(Float, default=0)
    invoice = relationship(Invoice)

    @property
    def serialize(self):
        """Return object data in easily serializeable format"""

        return {
            'id': self.id,
            'invoice_id': self.invoice_id,
            'description': self.description,
            'itemType': self.itemType,
            'hsnCode': self.hsnCode,
            'quantity': self.quantity,
            'rate': self.rate,
            'tax': self.tax,
            'cgst': self.cgst,
            'sgst': self.sgst,
            'igst': self.igst,
            'amount': self.amount
        }


class Config(Base):

    __tablename__ = "config"

    id = Column(Integer, primary_key=True)
    name = Column(String(200), default="")
    value = Column(String(2000), default="")

    @property
    def serialize(self):
        """Return object data in easily serializeable format"""

        return {
            'id': self.id,
            "name": self.name,
            "value": self.value
        }

dbpath = 'sqlite:///invoice.db'
if platform.system() == 'Windows':
    dbpath = 'sqlite:///' + os.getenv('LOCALAPPDATA') + '\\Programs\\InvoiceWithRoshi\\database\\invoice.db'

engine = create_engine(dbpath)

Base.metadata.create_all(engine)
